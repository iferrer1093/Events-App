package com.example.petinterface

class Dog (val name: String): Pet{
    override fun play(): String {
        return "This dude plays!"
    }

    override fun friendlyName(): String {
        return "This dude's friendly name is Doggie. His real name is $name"
    }


}