package com.example.petinterface

class Cat (val name: String): Pet{
    override fun play(): String {
        return "This dude plays!"
    }

    override fun friendlyName(): String {
        return "This dude's friendly name is Kitty. His real name is $name"
    }
}