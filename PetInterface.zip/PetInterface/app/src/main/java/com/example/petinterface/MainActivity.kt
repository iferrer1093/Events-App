package com.example.petinterface

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    fun adoptPet(view: View) {
        val nameEditText = findViewById<EditText>(R.id.petNameEditText)
        val petName = nameEditText.text.toString()
        val petTypeGroup = findViewById<RadioGroup>(R.id.petTypeRadioGroup)
        val selectedId = petTypeGroup.checkedRadioButtonId

        val pet: Pet =
            if (selectedId == R.id.dogRadioButton) {
                Dog(petName)
            } else {
                Cat(petName)
                RoboDog(petName)
            }

        val message = pet.friendlyName() + "\n" + pet.play()

        val resultTextView = findViewById<TextView>(R.id.resultTextView)
        resultTextView.text = message
    }



}