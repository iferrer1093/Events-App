package com.example.petinterface

interface Pet {
    fun play(): String {
        return "This dude fetches the ball"
    }

    fun friendlyName(): String {
        return "John"
    }
}