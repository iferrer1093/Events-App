package com.example.petinterface

class RoboDog (val name: String): Pet{
    override fun play(): String {
        return "This dude plays! $name"
    }

    override fun friendlyName(): String {
        return "This dude's friendly name is Robot. His real name is $name"

    }
}