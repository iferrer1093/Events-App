package com.example.petinterface

// IMPORTANT: This package line must match your app package

import org.junit.Assert.*
import org.junit.Test

class PetInterfaceTest {

    @Test
    fun pet_isInterface() {
        assertTrue(
            "Pet must be an interface",
            Pet::class.java.isInterface
        )
    }

    @Test
    fun pet_definesPlayFunction() {
        val methodNames = Pet::class.java.methods.map { it.name }
        assertTrue(
            "Pet must define play()",
            methodNames.contains("play")
        )
    }

    @Test
    fun pet_definesFriendlyNameFunction() {
        val methodNames = Pet::class.java.methods.map { it.name }
        assertTrue(
            "Pet must define friendlyName()",
            methodNames.contains("friendlyName")
        )
    }

    @Test
    fun pet_play_returnsString() {
        val playMethod = Pet::class.java.getMethod("play")
        assertEquals(
            "play() must return a String",
            String::class.java,
            playMethod.returnType
        )
    }

    @Test
    fun pet_friendlyName_returnsString() {
        val friendlyNameMethod = Pet::class.java.getMethod("friendlyName")
        assertEquals(
            "friendlyName() must return a String",
            String::class.java,
            friendlyNameMethod.returnType
        )
    }
}