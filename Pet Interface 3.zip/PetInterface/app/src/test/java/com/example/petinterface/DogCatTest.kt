package com.example.petinterface
import org.junit.Assert.*
import org.junit.Test

class DogCatTest {

    @Test
    fun dog_canBeStoredAsPet() {
        val p: Pet = Dog("Fido")
        assertNotNull(p)
    }

    @Test
    fun cat_canBeStoredAsPet() {
        val p: Pet = Cat("Mochi")
        assertNotNull(p)
    }

    @Test
    fun dog_outputsIncludeName() {
        val name = "Diesel"
        val dog: Pet = Dog(name)
        assertTrue(dog.friendlyName().contains(name, ignoreCase = true))
        assertTrue(dog.play().contains(name, ignoreCase = true))
    }

    @Test
    fun cat_outputsIncludeName() {
        val name = "Luna"
        val cat: Pet = Cat(name)
        assertTrue(cat.friendlyName().contains(name, ignoreCase = true))
        assertTrue(cat.play().contains(name, ignoreCase = true))
    }
}